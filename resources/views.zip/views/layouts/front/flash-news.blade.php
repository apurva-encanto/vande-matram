<div class="row mb-3 mt-1">
    <div class="col-md-12">
        <button class="label ripple">Top News</button>
        <div class="owl-carousel owl-theme">
            <div class="item"><p class="topNews-title">Economic Growth Is Essential. So Is Resilience</p></div>
            <div class="item"><p class="topNews-title">The Perfect Candidate for a Fallen Party</p></div>
            <div class="item"><p class="topNews-title">Latest blown lead for Raiders signals enough is enough of McDaniels</p></div>
            <div class="item"><p class="topNews-title">The Most Important Amicus Brief in the History of the World</p></div>
            <div class="item"><p class="topNews-title">5</p></div>
            <div class="item"><p class="topNews-title">6</p></div>
            <div class="item"><p class="topNews-title">7</p></div>
            <div class="item"><p class="topNews-title">8</p></div>
            <div class="item"><p class="topNews-title">9</p></div>
            <div class="item"><p class="topNews-title">10</p></div>
            <div class="item"><p class="topNews-title">11</p></div>
            <div class="item"><p class="topNews-title">12</p></div>
        </div>
    </div>
</div>